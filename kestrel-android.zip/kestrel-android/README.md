# Kestrel Messenger for Android

A WebView app that bundles the Kestrel Messenger demo (`app/src/main/assets/index.html`).
This project was written without access to the Android SDK, so it has not been compiled yet.

## Build the APK

**Option 1: Android Studio**
1. Open this folder in Android Studio (File > Open) and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

**Option 2: GitHub, no local setup**
1. Push this folder to a new GitHub repository.
2. Open the Actions tab, run "Build APK", and download `kestrel-debug-apk` from the run.

**Option 3: command line**
With JDK 17, the Android SDK (API 34) and Gradle 8.9 installed:
`gradle assembleDebug`

## Install
Copy the APK to your phone and open it. Android will ask you to allow installs from that source.

## Notes
- The app works offline. Fonts load from Google Fonts when online and fall back to system fonts otherwise.
- Photo and file attachments use the phone's file picker.
- The Back button closes chats, panels and dialogs before leaving the app.
- Contacts, channels and bots are scripted. Real messaging between people needs a server, which this project does not include.
- To publish on Google Play you need a signed release build (`assembleRelease` with your own keystore).
